package dice.client.web;

public final class UpdateEmailResponse extends DiceResponse {

}
