package dice.client.web;

public final class SetClientSeedResponse extends DiceResponse {

}
