package dice.client.web;

public final class UpdateEmergencyAddressResponse extends DiceResponse {

}
